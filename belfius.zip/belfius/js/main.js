  const chatButton = document.getElementById('chatButton');
  const hidden = document.getElementById('chat');

  chatButton.addEventListener('click', () => {
    // Přepínání mezi skrytým a viditelným
    if (hidden.style.display === 'none' || hidden.style.display === '') {
      hidden.style.display = 'block';
    } else {
      hidden.style.display = 'none';
    }
  });

  const dashboardButton = document.getElementById('dashboards');
  const hiddenDashboard = document.getElementById('dashboard');

  dashboardButton.addEventListener('click', () => {
    // Přepínání mezi skrytým a viditelným
    if (hiddenDashboard.style.display === 'none' || hiddenDashboard.style.display === '') {
      hiddenDashboard.style.display = 'block';
      hiddenDecision.style.display = 'none';
      hiddenaiSuggest.style.display = 'none';
      hidden.style.display = 'none';
      hiddenProfile.style.display = 'none';
    } else {
      hiddenDashboard.style.display = 'none';
    }
  });  

  const aiSuggestButton = document.getElementById('aiSuggest');
  const hiddenaiSuggest = document.getElementById('aiSuggestDashboard');

  aiSuggestButton.addEventListener('click', () => {
    // Přepínání mezi skrytým a viditelným
    if (hiddenaiSuggest.style.display === 'none' || hiddenaiSuggest.style.display === '') {
      hiddenaiSuggest.style.display = 'block';
      hiddenDashboard.style.display = 'none';
      hiddenDecision.style.display = 'none';
      hidden.style.display = 'none';
      hiddenProfile.style.display = 'none';
    } else {
      hiddenaiSuggest.style.display = 'none';
    }
  });  

  const profileButton = document.getElementById('profile');
  const hiddenProfile = document.getElementById('profileDashboard');

  profileButton.addEventListener('click', () => {
    // Přepínání mezi skrytým a viditelným
    if (hiddenProfile.style.display === 'none' || hiddenProfile.style.display === '') {
      hiddenProfile.style.display = 'block';
      hiddenDashboard.style.display = 'none';
      hiddenDecision.style.display = 'none';
      hidden.style.display = 'none';
      hiddenaiSuggest.style.display = 'none';
    } else {
      hiddenProfile.style.display = 'none';
    }
  });  


  

const chat = document.getElementById("chat");

const dialog = [
    { from: "me", text: "I wanna go to Thailand next April. Dream trip. What do I do?" },
    { from: "other", text: "Say less 🌴<br>What’s your budget?" },

    { from: "me", text: "€3,500 by end of March." },
    { from: "other", text: "Bet. Goal locked 🔒<br>Scanning your spending habits… 👀" },
    { from: "other", text: "My \"Fast-Track to Thailand\" " }
    


];

let index = 0;
let isTyping = false;

function showTyping() {
    const box = document.createElement("div");
    box.className = "typing";
    box.id = "typingBox";
    box.innerHTML = `<div class="dot"></div><div class="dot"></div><div class="dot"></div>`;
    chat.appendChild(box);
    chat.scrollTop = chat.scrollHeight;
}

function removeTyping() {
    const box = document.getElementById("typingBox");
    if (box) box.remove();
}

function showDivByID($id) {
    const box = document.getElementById($id);
    hidden.style.display = 'block';
}

function typeMessage(from, text) {
    return new Promise(resolve => {
        isTyping = true;

        if (from === "other") showTyping();

        setTimeout(() => {
            removeTyping();

            const bubble = document.createElement("div");
            bubble.className = "msg " + from;

            let i = 0;
            const interval = setInterval(() => {
                bubble.innerHTML = text.slice(0, i);
                if (i === 0) chat.appendChild(bubble);
                chat.scrollTop = chat.scrollHeight;

                i++;
                if (i > text.length) {
                    clearInterval(interval);
                    isTyping = false;
                    resolve();
                }
            }, 25);
        }, from === "other" ? 700 : 200);
    });
}

async function nextMessage() {
    if (isTyping) return;
    if (index >= dialog.length) return;

    const msg = dialog[index];
    index++;

    await typeMessage(msg.from, msg.text);
}

chat.addEventListener("click", nextMessage);



  

 const decisionButton = document.getElementById('decision');
  const hiddenDecision = document.getElementById('decisionDashboard');

  
    const fire = document.getElementById("fire");
  const sliderHeight = 300; // výška slideru
  const minSize = 20;       // malý dole
  const maxSize = 80;       // velký nahoře

  document.querySelector(".fire-slider").addEventListener("mousemove", (e) => {
    if (e.buttons !== 1) return;

    const sliderTop = e.currentTarget.getBoundingClientRect().top;
    let pos = e.clientY - sliderTop;

    pos = Math.max(0, Math.min(sliderHeight, pos));

    fire.style.top = pos + "px";

    // ratio 0 = nahoře, 1 = dole
    const ratio = pos / sliderHeight;

    // Aby byl dole malý a nahoře velký:
    const size = minSize + (1 - ratio) * (maxSize - minSize);

    fire.style.fontSize = size + "px";
  });